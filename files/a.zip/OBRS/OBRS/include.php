<?php 
$connec=@mysql_connect("localhost","root","");
$db=mysql_select_db("bus booking system");

 ?>